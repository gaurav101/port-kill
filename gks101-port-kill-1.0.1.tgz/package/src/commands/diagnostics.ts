/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface CommandFailureContext {
  command: string;
  status?: number | null;
  stderr?: string;
  error?: string;
}

export function buildCommandFailureMessage(context: CommandFailureContext): string {
  const stderr = normalizeMessage(context.stderr);
  const runtimeError = normalizeMessage(context.error);
  const rawReason = stderr || runtimeError || 'The command exited unsuccessfully without stderr output.';
  const diagnosis = diagnoseFailure(rawReason);
  const statusText = typeof context.status === 'number' ? ` Exit code: ${context.status}.` : '';

  return [
    `Command failed: ${context.command}.${statusText}`,
    `Reason: ${rawReason}`,
    `Likely issue: ${diagnosis.issue}`,
    `Possible fix: ${diagnosis.fix}`
  ].join(' ');
}

function normalizeMessage(message?: string): string {
  return (message || '').trim().replace(/\s+/g, ' ');
}

function diagnoseFailure(reason: string): { issue: string; fix: string } {
  const lowerReason = reason.toLowerCase();

  if (
    lowerReason.includes('operation not permitted') ||
    lowerReason.includes('permission denied') ||
    lowerReason.includes('not permitted') ||
    lowerReason.includes('access is denied')
  ) {
    return {
      issue: 'the current user does not have permission to terminate the target process.',
      fix: 'run the command from the same user that owns the process, stop the owning application manually, or retry with elevated privileges such as sudo/Admin when appropriate.'
    };
  }

  if (
    lowerReason.includes('no such process') ||
    lowerReason.includes('not found') ||
    lowerReason.includes('not running') ||
    lowerReason.includes('no instance')
  ) {
    return {
      issue: 'the process exited after discovery but before termination was attempted.',
      fix: 'rerun port-kill, verify the port is still in use, or restart the owning service before retrying.'
    };
  }

  if (lowerReason.includes('invalid signal') || lowerReason.includes('unknown signal')) {
    return {
      issue: 'the selected signal is not supported by this shell or operating system.',
      fix: 'use a standard POSIX signal such as SIGTERM, SIGINT, or SIGKILL.'
    };
  }

  if (
    lowerReason.includes('command not found') ||
    lowerReason.includes('not recognized') ||
    lowerReason.includes('not installed')
  ) {
    return {
      issue: 'a required system command is unavailable in the current environment.',
      fix: 'install the missing system utility or run from a shell where it is available on PATH.'
    };
  }

  return {
    issue: 'the operating system rejected the termination command.',
    fix: 'rerun with --verbose, verify the process owner and PID, then try a graceful signal such as --signal SIGTERM or elevated privileges if the process is protected.'
  };
}
