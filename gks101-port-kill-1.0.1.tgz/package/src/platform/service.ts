/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PortKillOptions, PortKillResult } from '../types';
import { createLogger } from '../shared/logger';
import { PlatformStrategyFactory } from './factory';
import { createDryRunResult, createFreePortResult, createTerminationResult } from './results';

function getFallbackSignal(options: PortKillOptions): string {
  return options.force !== false ? 'SIGKILL' : 'SIGTERM';
}

/**
 * Core function to terminate processes running on a specific port.
 */
export function killSinglePort(port: number, options: PortKillOptions = {}): PortKillResult {
  const timestamp = new Date().toISOString();
  const log = createLogger(options);
  const strategy = PlatformStrategyFactory.create();

  log(`Initiating port-kill routine for port: ${port}...`, 'info');

  const pids = strategy.findPids(port, log);

  if (pids.length === 0) {
    const result = createFreePortResult(port, timestamp);
    log(result.message, 'info');
    return result;
  }

  log(`Discovered active processes on port ${port}: PIDs [${pids.join(', ')}]`, 'info');

  if (options.dryRun) {
    const result = createDryRunResult({ port, pids, timestamp });
    log(result.message, 'info');
    return result;
  }

  const result = strategy.terminatePids(pids, options, log);
  return createTerminationResult(
    { port, pids, timestamp },
    strategy,
    result,
    getFallbackSignal(options)
  );
}
