/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PortKillResult } from '../types';
import { PlatformStrategy, TerminationResult } from './strategies';

export interface PortResultContext {
  port: number;
  pids: number[];
  timestamp: string;
}

export function createFreePortResult(port: number, timestamp: string): PortKillResult {
  return {
    port,
    success: true,
    pids: [],
    message: `Port ${port} is free. No active processes found.`,
    timestamp
  };
}

export function createDryRunResult(context: PortResultContext): PortKillResult {
  const { port, pids, timestamp } = context;

  return {
    port,
    success: true,
    pids,
    message: `[DRY_RUN] Discovered active process tree [${pids.join(', ')}] on port ${port}. No kill signal sent.`,
    timestamp
  };
}

export function createTerminationResult(
  context: PortResultContext,
  strategy: PlatformStrategy,
  result: TerminationResult,
  fallbackSignal: string
): PortKillResult {
  if (strategy.name === 'windows') {
    return createWindowsTerminationResult(context, result);
  }

  return createUnixTerminationResult(context, result, result.signal || fallbackSignal);
}

function createWindowsTerminationResult(
  context: PortResultContext,
  result: TerminationResult
): PortKillResult {
  const { port, pids, timestamp } = context;

  return {
    port,
    success: result.success,
    pids,
    message: result.success
      ? `Successfully terminated all processes on port ${port}.`
      : `Partial failure or error encountered during process termination on Windows.`,
    error: result.error,
    timestamp
  };
}

function createUnixTerminationResult(
  context: PortResultContext,
  result: TerminationResult,
  signal: string
): PortKillResult {
  const { port, pids, timestamp } = context;

  return {
    port,
    success: result.success,
    pids,
    message: result.success
      ? `Successfully terminated all processes on port ${port} using ${signal}.`
      : `Failed to terminate processes on port ${port} using ${signal}.`,
    error: result.error,
    timestamp
  };
}
