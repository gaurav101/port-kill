/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PortKillOptions } from '../types';
import { PortKillLog } from '../shared/logger';
import { runCommand } from '../commands/runner';
import { PlatformCommandFactory } from '../commands/factories';

export interface TerminationResult {
  success: boolean;
  error?: string;
  signal?: string;
}

export interface PlatformStrategy {
  readonly name: 'unix' | 'windows';
  findPids(port: number, log: PortKillLog): number[];
  terminatePids(pids: number[], options: PortKillOptions, log: PortKillLog): TerminationResult;
}

export class UnixPortStrategy implements PlatformStrategy {
  readonly name = 'unix' as const;

  constructor(private readonly commandFactory: PlatformCommandFactory) {}

  findPids(port: number, log: PortKillLog): number[] {
    const [lsofCmd, fuserCmd] = this.commandFactory.createFindCommands(port);
    const { stdout, success } = runCommand(lsofCmd, log);

    if (success && stdout.trim()) {
      const pids = stdout
        .split('\n')
        .map(line => parseInt(line.trim(), 10))
        .filter(pid => !isNaN(pid));

      log(`lsof found PIDs on port ${port}: [${pids.join(', ')}]`, 'debug');
      return pids;
    }

    log(`lsof yielded no active PIDs for port ${port}. Trying alternative "fuser" fallback...`, 'debug');
    const fuserResult = runCommand(fuserCmd, log);

    if (fuserResult.stdout.trim()) {
      const pids = fuserResult.stdout
        .split(/\s+/)
        .map(part => parseInt(part.trim(), 10))
        .filter(pid => !isNaN(pid));

      if (pids.length > 0) {
        log(`fuser fallback successfully identified PIDs on port ${port}: [${pids.join(', ')}]`, 'debug');
        return pids;
      }
    }

    log(`No processes identified on port ${port} via lsof or fuser.`, 'debug');
    return [];
  }

  terminatePids(pids: number[], options: PortKillOptions, log: PortKillLog): TerminationResult {
    const force = options.force !== false;
    const signal = options.signal || (force ? 'SIGKILL' : 'SIGTERM');

    log(`Preparing to send signal ${signal} to PIDs: [${pids.join(', ')}]`, 'info');

    const killCmd = this.commandFactory.createKillCommand(pids, signal) as string;
    const { success, error } = runCommand(killCmd, log);

    if (success) {
      log(`Processes [${pids.join(', ')}] terminated successfully.`, 'info');
      return { success: true, signal };
    }

    log(`Failed to terminate processes via Unix kill command.`, 'error');
    return { success: false, error, signal };
  }
}

export class WindowsPortStrategy implements PlatformStrategy {
  readonly name = 'windows' as const;

  constructor(private readonly commandFactory: PlatformCommandFactory) {}

  findPids(port: number, log: PortKillLog): number[] {
    const [netstatCmd] = this.commandFactory.createFindCommands(port);
    const { stdout, success } = runCommand(netstatCmd, log);

    if (!success || !stdout) {
      log('Failed to query active TCP sockets using netstat on Windows.', 'warn');
      return [];
    }

    const pids: number[] = [];
    const lines = stdout.split('\n');

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;

      const parts = trimmed.split(/\s+/);
      if (parts.length < 5) continue;

      const localAddress = parts[1];
      const pidStr = parts[parts.length - 1];
      const pid = parseInt(pidStr, 10);

      if (isNaN(pid)) continue;

      const portMatch = new RegExp(`[:\\]]${port}$`);
      if (portMatch.test(localAddress) && !pids.includes(pid)) {
        pids.push(pid);
      }
    }

    log(`netstat identified PIDs on Windows port ${port}: [${pids.join(', ')}]`, 'debug');
    return pids;
  }

  terminatePids(pids: number[], options: PortKillOptions, log: PortKillLog): TerminationResult {
    const force = options.force !== false;
    log(`Preparing to terminate Windows processes. Force: ${force}, PIDs: [${pids.join(', ')}]`, 'info');

    let successCount = 0;
    const errors: string[] = [];
    const killCommands = this.commandFactory.createKillCommand(pids, force) as string[];

    pids.forEach((pid, index) => {
      const result = runCommand(killCommands[index], log);

      if (result.success) {
        log(`Windows process ${pid} (and its child processes) terminated.`, 'info');
        successCount++;
      } else {
        log(`Failed to terminate Windows process ${pid}: ${result.error}`, 'error');
        if (result.error) errors.push(result.error);
      }
    });

    const allSucceeded = successCount === pids.length;
    return {
      success: allSucceeded,
      error: allSucceeded ? undefined : errors.join('; ')
    };
  }
}
