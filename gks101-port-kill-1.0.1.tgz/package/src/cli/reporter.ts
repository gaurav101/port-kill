/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PortKillOptions, PortKillResult } from '../types';

export function printVerboseExecutionDetails(ports: number[], options: PortKillOptions): void {
  if (!options.verbose) return;

  console.log(`[port-kill] Targeting ports: [${ports.join(', ')}]`);
  console.log(`[port-kill] Options configured:`, JSON.stringify({ ...options, port: undefined }, null, 2));
}

export function printResults(results: PortKillResult[]): number {
  let exitCode = 0;

  for (const res of results) {
    if (res.success) {
      if (res.pids.length > 0) {
        console.log(`✓ [Port ${res.port}] Process tree killed: [${res.pids.join(', ')}].`);
      } else {
        console.log(`✓ [Port ${res.port}] Already free (no active processes found).`);
      }
    } else {
      console.error(`✗ [Port ${res.port}] Terminate action failed.`);
      if (res.error) {
        console.error(`  ↳ Error detail: ${res.error}`);
      }
      exitCode = 1;
    }
  }

  return exitCode;
}
