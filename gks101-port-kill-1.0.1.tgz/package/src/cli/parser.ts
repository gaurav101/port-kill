/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PortKillOptions } from '../types';
import { CLI_ERRORS } from './messages';

export type CliParseResult =
  | { type: 'help' }
  | { type: 'version' }
  | { type: 'error'; message: string }
  | { type: 'run'; ports: number[]; options: PortKillOptions };

export function parseCliArgs(args: string[]): CliParseResult {
  if (args.includes('--help') || args.includes('-h') || args.length === 0) {
    return { type: 'help' };
  }

  if (args.includes('--version') || args.includes('-v')) {
    return { type: 'version' };
  }

  const ports: number[] = [];
  const options: PortKillOptions = {
    port: [],
    force: true,
    verbose: false,
    dryRun: false
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--verbose' || arg === '-d') {
      options.verbose = true;
    } else if (arg === '--dry-run') {
      options.dryRun = true;
    } else if (arg === '--no-force') {
      options.force = false;
    } else if (arg === '--signal' || arg === '-s') {
      const nextArg = args[i + 1];
      if (nextArg && !nextArg.startsWith('-')) {
        options.signal = nextArg;
        i++;
      } else {
        return { type: 'error', message: CLI_ERRORS.MISSING_SIGNAL };
      }
    } else {
      const port = parseInt(arg, 10);
      if (isNaN(port)) {
        return { type: 'error', message: CLI_ERRORS.invalidPortOrOption(arg) };
      }
      ports.push(port);
    }
  }

  if (ports.length === 0) {
    return { type: 'error', message: CLI_ERRORS.NO_PORTS };
  }

  options.port = ports;
  return { type: 'run', ports, options };
}
